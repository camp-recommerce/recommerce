package com.recommerceAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecommerceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecommerceApiApplication.class, args);
	}

}
