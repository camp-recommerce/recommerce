package com.recommerceAPI.domain;

// 사용자의 역할을 나타내는 enum
public enum UserRole {
    USER,  // 일반 사용자
    ADMIN  // 관리자

}


