package com.recommerceAPI.repository;

public class PurchaseItemRepositoryTests {
}
