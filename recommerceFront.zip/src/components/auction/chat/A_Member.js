import React from "react";

export const Member = (props) => {
  console.log(props);
  return (
    <>
      <div>유저 목록</div>
      <p>{props.member}</p>
    </>
  );
};
